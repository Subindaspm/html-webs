<?php
$pageTitle = 'ACLOVEN P - Aceclofenac + Paracetamol Tablets | Invenza Life Sciences';
$pageDescription = 'ACLOVEN P - Aceclofenac + Paracetamol Tablets. Quality-assured pharmaceutical product manufactured by WHO-GMP certified facilities. Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products meet strict quality and regulatory standards.';
$pageBannerTitle = 'ACLOVEN P';
$pageBannerImage = 'assets/images/banner-slide-2.png';
include 'includes/header.php';
include 'includes/nav.php';
include 'includes/page-banner.php';
?>

<section class="products-page-section">
    <div class="container">
        <div class="product-detail-page">
            <div class="product-detail-image">
                <img src="assets/images/banner-pills-2.png" alt="ACLOVEN P">
            </div>
            <div class="product-detail-content">
                <h1 class="product-detail-title">ACLOVEN P</h1>
                <p class="product-detail-subtitle">Aceclofenac + Paracetamol Tablets</p>
                <div class="product-detail-description">
                    <p>ACLOVEN P is a combination medication containing Aceclofenac and Paracetamol, providing effective pain relief and anti-inflammatory action. This pharmaceutical product is part of Invenza's range of quality-assured medicines manufactured by WHO-GMP certified facilities.</p>
                    <p>Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products are manufactured by WHO, GMP, GLP & ISO certified facilities and meet strict quality and regulatory standards.</p>
                </div>
                <div class="product-detail-info">
                    <h3>Product Information</h3>
                    <ul>
                        <li><strong>Composition:</strong> Aceclofenac + Paracetamol</li>
                        <li><strong>Form:</strong> Tablets</li>
                        <li><strong>Manufacturing:</strong> WHO-GMP, GLP & ISO certified facilities</li>
                        <li><strong>Quality Standards:</strong> Strict quality and regulatory compliance</li>
                    </ul>
                </div>
                <div class="product-detail-cta">
                    <a href="contact.php" class="btn">Contact Us for More Information</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/cta-banner.php'; ?>
<?php include 'includes/footer.php'; ?>
