# GitHub Authentication Guide

## Quick Method: Push with Token

Run this command in your terminal:

```bash
cd /Users/subin/Documents/html/invenza-website
git push -u origin main
```

When prompted:
- **Username**: `Subindaspm`
- **Password**: Enter your Personal Access Token (see below)

## Create a Personal Access Token

1. Go to: https://github.com/settings/tokens
2. Click **"Generate new token"** → **"Generate new token (classic)"**
3. Fill in:
   - **Note**: "Invenza Website Push"
   - **Expiration**: Choose your preference (90 days recommended)
   - **Select scopes**: Check ✅ **`repo`** (this gives full repository access)
4. Click **"Generate token"**
5. **Copy the token immediately** (you won't see it again!)
6. Use this token as your password when git prompts you

## Alternative: Store Credentials

After pushing once with the token, you can store it:

```bash
# This will save your credentials for future use
git config --global credential.helper osxkeychain
```

Then next time you push, macOS Keychain will remember your token.

## Verify Authentication

After successful push, verify:
```bash
git remote -v
```

You should see:
```
origin  https://github.com/Subindaspm/html-webs.git (fetch)
origin  https://github.com/Subindaspm/html-webs.git (push)
```
