<?php
$pageTitle = 'Mefza Forte - Mefenamic Acid Tablets | Invenza Life Sciences';
$pageDescription = 'Mefza Forte - Mefenamic Acid Tablets. Quality-assured pharmaceutical product manufactured by WHO-GMP certified facilities. Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products meet strict quality and regulatory standards.';
$pageBannerTitle = 'Mefza Forte';
$pageBannerImage = 'assets/images/banner-slide-2.png';
include 'includes/header.php';
include 'includes/nav.php';
include 'includes/page-banner.php';
?>

<section class="products-page-section">
    <div class="container">
        <div class="product-detail-page">
            <div class="product-detail-image">
                <img src="assets/images/banner-pills-1.png" alt="Mefza Forte">
            </div>
            <div class="product-detail-content">
                <h1 class="product-detail-title">Mefza Forte</h1>
                <p class="product-detail-subtitle">Mefenamic Acid Tablets</p>
                <div class="product-detail-description">
                    <p>Mefza Forte contains Mefenamic Acid, a nonsteroidal anti-inflammatory drug (NSAID) used for pain relief and inflammation. This pharmaceutical product is part of Invenza's range of quality-assured medicines manufactured by WHO-GMP certified facilities.</p>
                    <p>Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products are manufactured by WHO, GMP, GLP & ISO certified facilities and meet strict quality and regulatory standards.</p>
                </div>
                <div class="product-detail-info">
                    <h3>Product Information</h3>
                    <ul>
                        <li><strong>Composition:</strong> Mefenamic Acid</li>
                        <li><strong>Form:</strong> Tablets</li>
                        <li><strong>Manufacturing:</strong> WHO-GMP, GLP & ISO certified facilities</li>
                        <li><strong>Quality Standards:</strong> Strict quality and regulatory compliance</li>
                    </ul>
                </div>
                <div class="product-detail-cta">
                    <a href="contact.php" class="btn">Contact Us for More Information</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/cta-banner.php'; ?>
<?php include 'includes/footer.php'; ?>
