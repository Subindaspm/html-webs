# Invenza Life Sciences Website

A PHP-based website for Invenza Life Sciences pharmaceutical company.

## Prerequisites

- PHP 7.4 or higher
- A web browser

## Installation

### Install PHP (macOS)

If you don't have PHP installed, you can install it using Homebrew:

1. **Install Homebrew** (if not already installed):
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

2. **Install PHP**:
   ```bash
   brew install php
   ```

3. **Verify installation**:
   ```bash
   php --version
   ```

### Alternative: Install PHP without Homebrew

You can also download PHP directly from [php.net](https://www.php.net/downloads.php) or use MAMP/XAMPP which includes PHP.

## Running the Project Locally

### Option 1: Using the provided script (Recommended)

```bash
./run-local.sh
```

Or:

```bash
bash run-local.sh
```

### Option 2: Using PHP directly

```bash
php -S localhost:8000
```

### Option 3: Using a different port

```bash
php -S localhost:3000
```

## Access the Website

Once the server is running, open your browser and navigate to:

- **Homepage**: http://localhost:8000
- **About**: http://localhost:8000/about.php
- **Products**: http://localhost:8000/products.php
- **Contact**: http://localhost:8000/contact.php
- **Gallery**: http://localhost:8000/gallery.php

## Stopping the Server

Press `Ctrl+C` in the terminal where the server is running.

## Project Structure

```
invenza-website/
├── index.php          # Homepage
├── about.php          # About page
├── products.php       # Products page
├── contact.php        # Contact page
├── gallery.php        # Gallery page
├── includes/          # PHP includes (header, footer, nav, etc.)
├── assets/            # Images and other assets
├── css/               # Stylesheets
├── js/                # JavaScript files
└── run-local.sh       # Local development server script
```

## Notes

- The PHP built-in server is suitable for development only, not production
- Make sure all asset paths are correct relative to the document root
- For production deployment, use a proper web server like Apache or Nginx
