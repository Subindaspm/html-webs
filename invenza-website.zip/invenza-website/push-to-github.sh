#!/bin/bash
# Push to GitHub script
# Run this: bash push-to-github.sh

cd "$(dirname "$0")"
echo "Pushing to GitHub..."
echo "You will be prompted for your GitHub credentials."
echo ""
echo "Username: Enter your GitHub username"
echo "Password: Enter a Personal Access Token (not your password)"
echo ""
echo "To create a token:"
echo "1. Go to: https://github.com/settings/tokens"
echo "2. Click 'Generate new token (classic)'"
echo "3. Select 'repo' scope"
echo "4. Copy the token and use it as password"
echo ""
git push -u origin main
