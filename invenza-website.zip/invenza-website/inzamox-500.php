<?php
$pageTitle = 'Inzamox 500 - Amoxicillin 500mg Capsules | Invenza Life Sciences';
$pageDescription = 'Inzamox 500 - Amoxicillin 500mg Capsules. Quality-assured pharmaceutical product manufactured by WHO-GMP certified facilities. Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products meet strict quality and regulatory standards.';
$pageBannerTitle = 'Inzamox 500';
$pageBannerImage = 'assets/images/banner-slide-2.png';
include 'includes/header.php';
include 'includes/nav.php';
include 'includes/page-banner.php';
?>

<section class="products-page-section">
    <div class="container">
        <div class="product-detail-page">
            <div class="product-detail-image">
                <img src="assets/images/banner-pills-2.png" alt="Inzamox 500">
            </div>
            <div class="product-detail-content">
                <h1 class="product-detail-title">Inzamox 500</h1>
                <p class="product-detail-subtitle">Amoxicillin 500mg Capsules</p>
                <div class="product-detail-description">
                    <p>Inzamox 500 is an antibiotic medication containing Amoxicillin 500mg in capsule form. This pharmaceutical product is part of Invenza's range of quality-assured medicines manufactured by WHO-GMP certified facilities.</p>
                    <p>Invenza offers a range of quality-assured pharmaceuticals including tablets, dispersible tablets, capsules, and injections. Our products are manufactured by WHO, GMP, GLP & ISO certified facilities and meet strict quality and regulatory standards.</p>
                </div>
                <div class="product-detail-info">
                    <h3>Product Information</h3>
                    <ul>
                        <li><strong>Composition:</strong> Amoxicillin 500mg</li>
                        <li><strong>Form:</strong> Capsules</li>
                        <li><strong>Manufacturing:</strong> WHO-GMP, GLP & ISO certified facilities</li>
                        <li><strong>Quality Standards:</strong> Strict quality and regulatory compliance</li>
                    </ul>
                </div>
                <div class="product-detail-cta">
                    <a href="contact.php" class="btn">Contact Us for More Information</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/cta-banner.php'; ?>
<?php include 'includes/footer.php'; ?>
