# Quick Setup Guide

## Install PHP (Required First Step)

### Method 1: Using Homebrew (Recommended)

1. **Install Homebrew** (if not already installed):
   Open Terminal and run:
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```
   Follow the prompts and enter your password when asked.

2. **Install PHP**:
   ```bash
   brew install php
   ```

3. **Verify installation**:
   ```bash
   php --version
   ```

### Method 2: Using MAMP (Easier, GUI-based)

1. Download MAMP from: https://www.mamp.info/en/downloads/
2. Install MAMP
3. Start MAMP and use the built-in PHP
4. Point MAMP's document root to this project folder

## Run the Project

Once PHP is installed, run:

```bash
cd /Users/subin/Documents/html/invenza-website
./run-local.sh
```

Then open: **http://localhost:8000**

## Troubleshooting

- **"Connection Refused" error**: Make sure PHP is installed and the server is running
- **Port already in use**: Change the port in `run-local.sh` from `8000` to another port like `3000` or `8080`
