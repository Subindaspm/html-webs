#!/bin/bash
# PHP Installation Script for macOS
# Run this script in your terminal: bash install-php.sh

echo "=========================================="
echo "PHP Installation Guide for Invenza Website"
echo "=========================================="
echo ""

# Check if PHP is already installed
if command -v php &> /dev/null; then
    echo "✓ PHP is already installed!"
    php --version
    exit 0
fi

echo "PHP is not installed. Let's install it!"
echo ""

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
    echo "Step 1: Installing Homebrew..."
    echo "This will require your password."
    echo ""
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add Homebrew to PATH (for Apple Silicon Macs)
    if [ -f "/opt/homebrew/bin/brew" ]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zshrc
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
    
    echo ""
    echo "✓ Homebrew installed!"
    echo ""
else
    echo "✓ Homebrew is already installed!"
    echo ""
fi

# Install PHP
echo "Step 2: Installing PHP..."
brew install php

echo ""
echo "=========================================="
echo "Installation Complete!"
echo "=========================================="
echo ""
echo "Verifying PHP installation..."
php --version
echo ""
echo "✓ PHP is now installed!"
echo ""
echo "Next steps:"
echo "1. Run: ./run-local.sh"
echo "2. Open: http://localhost:8000"
echo ""
